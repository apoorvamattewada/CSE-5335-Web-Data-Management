1. Extract Nagaraju_Mohammad_Mattewada_Nangi_Mudraboyina.zip.
2. Open project folder.
3. Click on index page to view and navigate in the website.